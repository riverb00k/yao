package com.websarva.wings.android.yao;

import android.app.Activity;

public class AddMemo extends Activity {
}
